

$(document).ready(function() {
    
});




var fvIDInstances = (function(){
    var fvidIns = {
        loadData: [{ id: 'FVIE00000000000001', load_status1: 'Underloaded', load_status2: 'Overload', total_template: 9854, total_pool: 04 },
        { id: 'FVIE00000000000002', load_status1: 'Underloaded', load_status2: 'Overload', total_template: 16500, total_pool: 05 },
        { id: 'FVIE00000000000003', load_status1: 'Underloaded', load_status2: 'Overload', total_template: 9855, total_pool: 06 },
        { id: 'FVIE00000000000004', load_status1: 'Underloaded', load_status2: 'Overload', total_template: 9856, total_pool: 07 },
        { id: 'FVIE00000000000005', load_status1: 'Underloaded', load_status2: 'Overload', total_template: 9857, total_pool: 08 },
        { id: 'FVIE00000000000006', load_status1: 'Underloaded', load_status2: 'Overload', total_template: 9858, total_pool: 09 },
        { id: 'FVIE00000000000007', load_status1: 'Underloaded', load_status2: 'Overload', total_template: 9859, total_pool: 10 }]
    }
    //cache DOM
    var $ul = $('#fvidInstancs');
    debugger;

    //Custom Handlebar Templating
    var source = document.getElementById('fvidInstancs-template').innerHTML;
        var template = Handlebars.compile(source);
    var html = template(fvidIns);
    $ul.append(html);// = html;
   
    
	//var template = $ul.find('#fvidInstancs-template').html();
	////fviEinstDetai.updatePoolById();
	// function render() {
   //      $ul.html(Mustache.render(template, {fvidIns:fvidIns}));
 //     }	
	//render();

	var $btn = $ul.find('li button.fvidIns_edit');
	$btn.on('click', showActions);
	function showActions(){
      //  $box=$(this).attr('data-fvieID');
      //  alert($box);
	 
        $this = $(this).next(".fvidIns_actionlist");
        $this.toggle();
         $(".fvidIns_actionlist").not($this).hide();
      return false;
    }
    return{
        show1:showActions,
        fvie:fvidIns
    }
})();



var fvidInsDetail = (function(){
    var fvidInsDetail=[{pool_num:1,total_template:9854},
				 {pool_num:2,total_template:1587},
				 {pool_num:3,total_template:3242},
				 {pool_num:4,total_template:2427}];
				 
				 
    //cache DOM
    var $row = $('#fvidInstancsDetails');
  
    //var template = $el.find('#people-template').html();
	var template = $row.find('#fvidInstancsDetails-template').html();
	
	 function render() {
       $row.html(Mustache.render(template, {fvidInsDetail:fvidInsDetail}));
      }	
	  
	  function updatePoolById(idAsString){
		  
	  }
    render();
    return{
        updatePoolById:updatePoolById
    };
})();


// (function(){
	// var fvids={id:222,template_num:2222};
		  // var template = "<h6>FVID-ID: {{id}} ,Total templates : {{template_num}}</h6>";
// console.log(fvids);
// var view = Mustache.render(template,fvids);
// $('#sampleArea').html(view);
	// render();
// })();

/*donut chart   */
(function(d3) {
    'use strict';

    var dataset = [{
        label: 'Betelgeuse',
        count: 48
    }, {
        label: 'Cantaloupe',
        count: 52
    }];

    var width = 130;
    var height = 140;
    var radius = Math.min(width, height) / 2;
    var donutWidth = 12;
    var image_width = 32;
    var image_height = 32; // NEW

    var color = d3.scaleOrdinal(["#efefef", "#00e676", "#efefef"]); //d3.scaleOrdinal(d3.schemeCategory20b);
    // green:#8BC333
    // orange:#FF8B33
    // red: #E3514A
    // brightblue:#47BBDC
    // darkblue: #3895B0
    // darkergray: #424242
    // darkgray: #9E9E9E
    // lightgray: #E0E0E0
    //d3.scale.ordinal().range(["#8BC333", "#FF8B33", "#E3514A"]);
    var svg = d3.select('#chart')
        .append('svg')
        .attr('width', width)
        .attr('height', height)
        .append('g')
        .attr('transform', 'translate(' + (width / 2) +
            ',' + (height / 2) + ')');

    var arc = d3.arc()
        .innerRadius(radius - donutWidth) // NEW
        .outerRadius(radius);

    var pie = d3.pie()
        .value(function(d) {
            return d.count;
        })
        .sort(null);

    var path = svg.selectAll('path')
        .data(pie(dataset))
        .enter()
        .append('path')
        .attr('d', arc)
        .attr('fill', function(d, i) {
            return color(d.data.label);
        });
    svg.append("text")
        .attr("dy", ".4em")
        .style("text-anchor", "middle")
        .attr("class", "inside")
        .text(function(d) {
            return '52%';
        });
   
})(window.d3);


	
	 
