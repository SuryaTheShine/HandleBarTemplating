 $( document ).ready(function() {
	 
/*menu toggle */
 $(function(){
            $("#menu-toggle").click(function(e) {
                e.preventDefault();
                $("#sidebar_detail").toggle();
				$('#menu-toggle').removeClass("active");
            });           
          });
 /*menu toggle */  

 /*sidebar toggle */ 
  $('.sidebar ul li ').click(function(){
    $('.sidebar ul li').removeClass("active");
    $(this).addClass("active");
});
 /*sidebar toggle */ 
 
 /*FVID tab toggle */   
$("#fvidInstancs li").first().addClass("active");
$("#fvidInstancs li").click(function(e) {
	$('#fvidInstancs li').removeClass("active");
	$(this).addClass("active");
});  


var fvidInstancsArry = [];
$('#fvidInstancs li').each(function(i, elem) {
    fvidInstancsArry.push($(elem));
});

var fvidInstancsDetailsArry = [];
$('#fvidInstancsDetails .tab-pane').each(function(i, elem) {
    fvidInstancsDetailsArry.push($(elem));
});

 
 // for (var i = 0; i < fvidInstancsArry.length; i++) {
    // fvidInstancsArry[i].addEventListener(".click", function() {
        // alert("hi");
		// $('#fvidInstancs li').each(function(i, elem) {
		 // $("#fvidInstancsDetailsArry").each(function(j, elem) {
			  // if(indexOf[i]==indexOf[i]){
		 // // fvidInstancsDetailsArry[j].show();
	          // }
		// })
	// })	
// });
// }
 

	
	
	
	

//alert(fvidInstancsDetailsArry);


// $("#fvidInstancsDetails .tab-pane").first().show();

// var $el = $('#fvidInstancsDetails'); 
// var $ul = $el.find('.tab-pane');

// $("#fvidInstancs li").click(function(e) {
	
	// $('#fvidInstancs li').each(function(i, li) {
    // $(ul).each(function(j, li) {
        // // Now you can use $(ul) and $(li) to refer to the list and item
        // if (i===j) {
            // ...
        // }
    // });
// }); 
	
	
	
	
	
	// $('#fvidInstancsDetails .tab-pane').hide();
	// $(this).show();
// });  

       
 /*FVID tab toggle */      
		  

  
// $('#createdFVIDtab .round2 input[type="checkbox"]').click(function(){
	
	// if( $('#createdFVIDtab .round2 input[type="checkbox"]').attr("checked",true)){
		// alert("hi");
		// $(".FVID_tab").addClass("borderbox");
	// }
	
	// // else( $('#createdFVIDtab .round2 input[type="checkbox"]').attr("checked",false)){
	  // // $(".FVID_tab").removeClass("borderbox");
	// // }
// });


});

